from django.contrib import admin
from users.models import Users, Country, City
# Register your models here.

admin.site.register(Users)
admin.site.register(Country)
admin.site.register(City)



