from django.contrib import admin
from sales_app.models import  Sales
# Register your models here.

admin.site.register(Sales)
